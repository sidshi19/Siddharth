document.addEventListener("DOMContentLoaded", function () {
    const auth = firebase.auth();
const logout = document.querySelector("#harami");
logout.addEventListener('click', (e) => {
  e.preventDefault();
  auth.signOut().then(() => {
    window.location.href="index.html";
  });
});
});
firebase.auth().onAuthStateChanged(function (user) {
  const bookingButton = document.getElementById("bookingButton");
  
  if (user) {
    // User is signed in, show the booking button
    bookingButton.style.display = "block";
  } else {
    // User is not signed in, hide the booking button
    bookingButton.style.display = "none";
  }
});