// Log in User
document.addEventListener("DOMContentLoaded", function () {
  const auth = firebase.auth();
const loginForm = document.querySelector("#loginuser");
const loginForm1 = document.querySelector("#login1");
loginForm1.addEventListener('click', (e) => {
  e.preventDefault();

  // const email = document.querySelector("#loginemail").value;
  // const password = document.querySelector("#loginpassword").value;
  const email = loginForm["loginemail"].value;
  const password = loginForm["loginpassword"].value;
    console.log(email);
  auth.signInWithEmailAndPassword(email, password)
    .then((cred) => {
    //   loginForm1.reset();
      console.log('Logged in user!');
      // Redirect to index.html after successful login
      window.location.href = "cape.html";
    })
    .catch((error) => {
      console.error(error.message);
    });
});

});

