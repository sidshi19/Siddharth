//     // Import the functions you need from the SDKs you need
// import { initializeApp } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-app.js";
// import { getDatabase } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-database.js";
// import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-auth`.js";
//     // TODO: Add SDKs for Firebase products that you want to use
//     // https://firebase.google.com/docs/web/setup#available-libraries

//     // Your web app's Firebase configuration
//     const firebaseConfig = {
//         apiKey: "AIzaSyBSdiDElljKjqKkfrEiddp4LVYD3bZphbs",
//         authDomain: "rehab-fe6de.firebaseapp.com",
//         projectId: "rehab-fe6de",
//         storageBucket: "rehab-fe6de.appspot.com",
//         messagingSenderId: "411676054074",
//         appId: "1:411676054074:web:992b63c464d36af59b1b03",
//         measurementId: "G-55NWQQG88P"
//       };

//     // Initialize Firebase
//     firebase.initializeApp(firebaseConfig);

//     var first_name = document.getElementById('first_name').value;
// // Reference to your Firebase database
// var database = firebase.database();

// Function to save user registration data
// function saveUserData(firstName, lastName, birthdate, gender, email, password, phone) {
//   // Create a unique key for the user
//   var userKey = database.ref("users").push().key;

// Define the data to be saved
// var userData = {
//   first_name: firstName,
//   last_name: lastName,
//   birthdate: birthdate,
//   gender: gender,
//   email: email,
//   password: password,
//   phone: phone
// };

//   // Save the data under the "users" node with the unique key
//   var updates = {};
//   updates["/users/" + userKey] = userData;

//   // Perform the database update
//   return database.ref().update(updates);
// }

// // Example usage:
// document.getElementById("RehabReg").addEventListener("submit", function (e) {
//   e.preventDefault();

// var firstName = document.getElementById("first_name").value;
// var lastName = document.getElementById("last_name").value;
// var birthdate = document.getElementById("Birthdate").value;
// var gender = document.querySelector('input[name="gender"]:checked').value;
// var email = document.getElementById("email").value;
// var password = document.getElementById("password").value;
// var phone = document.getElementById("phone").value;

//   // Save user data to Firebase
//   saveUserData(firstName, lastName, birthdate, gender, email, password, phone);
// });

const signupBtn = document.querySelector("#RehabReg");
signupBtn.addEventListener("submit", (e) => {
  e.preventDefault();

  // const email = document.querySelector('#email').value;
  // const password = document.querySelector('#password').value;
  const email = signupBtn["email"].value;
  const password = signupBtn["password"].value;

  auth.createUserWithEmailAndPassword(email, password).then((cred) => {
    signupBtn.reset();
  });
});
//logout
const logout = document.querySelector("#logout");
logout.addEventListener("click", (e) => {
  e.preventDefault();
  auth.signOut().then(() => {
    console.log("user signed out");
  });
});
//login auth
// document.addEventListener("DOMContentLoaded", function () {
//   const auth = firebase.auth();

  // Log in User
  const loginForm = document.querySelector("#loginuser");
  const loginForm1 = document.querySelector("#login1");
  loginForm1.addEventListener('click', (e) => {
    e.preventDefault();

    // const email = document.querySelector("#loginemail").value;
    // const password = document.querySelector("#loginpassword").value;
    const email = loginForm["loginemail"].value;
    const password = loginForm["loginpassword"].value;
      console.log(email);
    auth.signInWithEmailAndPassword(email, password)
      .then((cred) => {
        loginForm1.reset();
        console.log('Logged in user!');
        // Redirect to index.html after successful login
        window.location.href = "index.html";
      })
      .catch((error) => {
        console.error(error.message);
      });
  });
// });

// auth.signInWithEmailAndPassword(email, password).then(cred => {
//   console.log('Logged in user!');
//   // loginform.reset(); // Reset the form
//   // // Redirect to index.html after successful login
//   // window.location.href = "index.html";
// }) .catch(error => {
//   console.log(error.message);
// })


// });
